import { createContext } from "react";

export const UserDataContext = createContext({})



export function getAppName(){
    return "Todo"
}